# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/trial20_family_holdout_s0/pb_pre_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.100

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 1767 | 0.121 | 0.975 | 0.024 | 0.048 | 0.006 |
| flow, no local-infra | 1589 | 0.116 | 0.975 | 0.027 | 0.053 | 0.007 |
| capture | 2 | 0.500 | 0.500 | 1.000 | 0.667 | 1.000 |

Flow ROC-AUC (max window logit) 0.466, PR-AUC 0.891; alerts per benign hour 4.5 over 0.22 h.
Time to detect (TP flows): median 0.955 s / 11 packets, p90 43.435 s / 11 packets. Decided on prefix: {9: 7, 10: 12, 11: 19, 12: 1}
Throughput 66032 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 1660 | 0.277 | 0.971 | 0.077 | 0.143 | 0.008 |
| flow, no local-infra | 1552 | 0.255 | 0.971 | 0.080 | 0.147 | 0.010 |
| capture | 2 | 0.500 | 0.500 | 1.000 | 0.667 | 1.000 |

Flow ROC-AUC (max window logit) 0.639, PR-AUC 0.816; alerts per benign hour 11.9 over 0.25 h.
Time to detect (TP flows): median 38.445 s / 13 packets, p90 55.209 s / 14 packets. Decided on prefix: {10: 30, 11: 5, 13: 43, 14: 15, 16: 5, 18: 2}
Throughput 59070 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
