# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/trial20_family_holdout_s0/pb_scratch_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.470

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 1767 | 0.105 | 1.000 | 0.007 | 0.014 | 0.000 |
| flow, no local-infra | 1589 | 0.099 | 1.000 | 0.008 | 0.015 | 0.000 |
| capture | 2 | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 |

Flow ROC-AUC (max window logit) 0.515, PR-AUC 0.906; alerts per benign hour 0.0 over 0.22 h.
Time to detect (TP flows): median 38.917 s / 10 packets, p90 104.502 s / 10 packets. Decided on prefix: {9: 4, 10: 7}
Throughput 64198 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 1660 | 0.218 | 0.500 | 0.004 | 0.008 | 0.014 |
| flow, no local-infra | 1552 | 0.193 | 0.625 | 0.004 | 0.008 | 0.010 |
| capture | 2 | 0.500 | 0.500 | 1.000 | 0.667 | 1.000 |

Flow ROC-AUC (max window logit) 0.613, PR-AUC 0.824; alerts per benign hour 19.8 over 0.25 h.
Time to detect (TP flows): median 83.135 s / 10 packets, p90 113.552 s / 11 packets. Decided on prefix: {10: 4, 11: 1}
Throughput 59257 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
