# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_s0/pb_scratch_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.662

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 46470 | 0.516 | 0.843 | 0.051 | 0.096 | 0.010 |
| flow, no local-infra | 39764 | 0.509 | 0.825 | 0.051 | 0.096 | 0.011 |
| capture | 108 | 0.454 | 0.289 | 1.000 | 0.449 | 0.702 |

Flow ROC-AUC (max window logit) 0.602, PR-AUC 0.627; alerts per benign hour 12.9 over 17.26 h.
Time to detect (TP flows): median 7.068 s / 18 packets, p90 53.227 s / 33 packets. Decided on prefix: {4: 1, 5: 3, 6: 7, 7: 8, 8: 258, 9: 21, 10: 140, 11: 18, 12: 76, 13: 40, 14: 39, 15: 28, 16: 273, 17: 24, 18: 22, 19: 62, 20: 25, 21: 35, 22: 11, 23: 6, 24: 7, 25: 9, 26: 8, 27: 6, 28: 7, 29: 14, 30: 4, 31: 3, 32: 45}
Throughput 55614 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 52944 | 0.477 | 0.855 | 0.057 | 0.106 | 0.012 |
| flow, no local-infra | 46474 | 0.467 | 0.843 | 0.057 | 0.107 | 0.014 |
| capture | 107 | 0.402 | 0.264 | 1.000 | 0.418 | 0.762 |

Flow ROC-AUC (max window logit) 0.617, PR-AUC 0.678; alerts per benign hour 15.8 over 17.68 h.
Time to detect (TP flows): median 1.169 s / 15 packets, p90 42.674 s / 28 packets. Decided on prefix: {4: 1, 5: 5, 6: 15, 7: 20, 8: 389, 9: 39, 10: 272, 11: 37, 12: 62, 13: 48, 14: 42, 15: 56, 16: 329, 17: 58, 18: 25, 19: 53, 20: 26, 21: 25, 22: 20, 23: 6, 24: 10, 25: 11, 26: 6, 27: 5, 28: 11, 29: 6, 30: 8, 31: 9, 32: 56}
Throughput 49979 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
