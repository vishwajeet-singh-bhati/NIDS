# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_s0/pb_pre_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.877

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 46470 | 0.527 | 0.886 | 0.074 | 0.136 | 0.010 |
| flow, no local-infra | 39764 | 0.520 | 0.871 | 0.074 | 0.136 | 0.011 |
| capture | 108 | 0.463 | 0.293 | 1.000 | 0.453 | 0.690 |

Flow ROC-AUC (max window logit) 0.621, PR-AUC 0.651; alerts per benign hour 13.0 over 17.26 h.
Time to detect (TP flows): median 10.471 s / 18 packets, p90 59.573 s / 38 packets. Decided on prefix: {4: 18, 5: 1, 6: 34, 7: 28, 8: 213, 9: 15, 10: 150, 11: 22, 12: 223, 13: 30, 14: 37, 15: 22, 16: 453, 17: 23, 18: 40, 19: 71, 20: 34, 21: 40, 22: 21, 23: 12, 24: 6, 25: 21, 26: 13, 27: 12, 28: 8, 29: 18, 30: 3, 31: 4, 32: 164}
Throughput 63993 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 52944 | 0.493 | 0.901 | 0.085 | 0.156 | 0.011 |
| flow, no local-infra | 46474 | 0.484 | 0.893 | 0.087 | 0.158 | 0.013 |
| capture | 107 | 0.402 | 0.264 | 1.000 | 0.418 | 0.762 |

Flow ROC-AUC (max window logit) 0.636, PR-AUC 0.701; alerts per benign hour 15.4 over 17.68 h.
Time to detect (TP flows): median 6.874 s / 17 packets, p90 62.847 s / 36 packets. Decided on prefix: {4: 19, 5: 2, 6: 38, 7: 25, 8: 529, 9: 19, 10: 176, 11: 31, 12: 109, 13: 40, 14: 90, 15: 94, 16: 452, 17: 69, 18: 56, 19: 94, 20: 51, 21: 189, 22: 40, 23: 19, 24: 15, 25: 17, 26: 21, 27: 11, 28: 14, 29: 14, 30: 20, 31: 4, 32: 223}
Throughput 57191 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
