# Stream replay report - hybrid_resnet

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_s0/hybrid_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 2.564

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 46470 | 0.640 | 0.969 | 0.296 | 0.454 | 0.010 |
| flow, no local-infra | 39764 | 0.656 | 0.969 | 0.338 | 0.502 | 0.011 |
| capture | 108 | 0.824 | 0.561 | 0.958 | 0.708 | 0.214 |

Flow ROC-AUC (max window logit) 0.791, PR-AUC 0.815; alerts per benign hour 12.8 over 17.26 h.
Time to detect (TP flows): median 0.439 s / 17 packets, p90 15.202 s / 54 packets. Decided on prefix: {4: 1, 6: 1, 7: 110, 8: 4952, 9: 18, 10: 106, 11: 65, 12: 82, 13: 75, 14: 87, 15: 59, 16: 1333, 17: 9, 18: 7, 19: 4, 20: 1, 21: 3, 22: 2, 23: 3, 24: 1, 25: 2, 26: 1, 27: 3, 29: 2, 30: 2, 31: 2, 32: 22}
Throughput 17679 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 52944 | 0.597 | 0.976 | 0.273 | 0.427 | 0.008 |
| flow, no local-infra | 46474 | 0.607 | 0.976 | 0.304 | 0.463 | 0.009 |
| capture | 107 | 0.776 | 0.489 | 1.000 | 0.657 | 0.286 |

Flow ROC-AUC (max window logit) 0.779, PR-AUC 0.830; alerts per benign hour 10.9 over 17.68 h.
Time to detect (TP flows): median 0.380 s / 17 packets, p90 11.237 s / 42 packets. Decided on prefix: {6: 1, 7: 101, 8: 5842, 9: 22, 10: 94, 11: 44, 12: 60, 13: 87, 14: 56, 15: 98, 16: 1463, 17: 4, 19: 2, 20: 1, 21: 3, 22: 8, 23: 1, 24: 4, 25: 1, 26: 2, 27: 5, 28: 1, 29: 1, 30: 3, 31: 2, 32: 28}
Throughput 15693 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
