# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_group_random_s0/pb_scratch_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.668

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 13088 | 0.546 | 0.704 | 0.022 | 0.042 | 0.008 |
| flow, no local-infra | 11332 | 0.532 | 0.691 | 0.023 | 0.044 | 0.009 |
| capture | 32 | 0.406 | 0.217 | 0.833 | 0.345 | 0.692 |

Flow ROC-AUC (max window logit) 0.581, PR-AUC 0.536; alerts per benign hour 10.0 over 5.49 h.
Time to detect (TP flows): median 1.118 s / 15 packets, p90 27.386 s / 42 packets. Decided on prefix: {4: 1, 7: 1, 8: 5, 9: 8, 10: 23, 11: 8, 12: 1, 13: 8, 14: 15, 15: 12, 16: 40, 17: 1, 19: 2, 20: 4, 21: 1, 26: 1}
Throughput 67186 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 18774 | 0.427 | 0.722 | 0.014 | 0.028 | 0.008 |
| flow, no local-infra | 16579 | 0.419 | 0.706 | 0.015 | 0.029 | 0.009 |
| capture | 32 | 0.469 | 0.292 | 1.000 | 0.452 | 0.680 |

Flow ROC-AUC (max window logit) 0.584, PR-AUC 0.653; alerts per benign hour 11.0 over 5.46 h.
Time to detect (TP flows): median 0.630 s / 16 packets, p90 28.888 s / 41 packets. Decided on prefix: {8: 6, 9: 1, 10: 27, 11: 2, 12: 15, 13: 4, 14: 11, 15: 6, 16: 67, 17: 4, 18: 2, 19: 5, 20: 1, 22: 1, 25: 1, 28: 1, 30: 1, 32: 1}
Throughput 68738 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
