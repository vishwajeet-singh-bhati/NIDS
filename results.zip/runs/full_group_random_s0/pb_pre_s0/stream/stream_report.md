# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_group_random_s0/pb_pre_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.312

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 13088 | 0.545 | 0.672 | 0.021 | 0.042 | 0.009 |
| flow, no local-infra | 11332 | 0.532 | 0.665 | 0.023 | 0.044 | 0.010 |
| capture | 32 | 0.281 | 0.185 | 0.833 | 0.303 | 0.846 |

Flow ROC-AUC (max window logit) 0.549, PR-AUC 0.512; alerts per benign hour 11.5 over 5.49 h.
Time to detect (TP flows): median 2.124 s / 15 packets, p90 35.776 s / 42 packets. Decided on prefix: {4: 3, 6: 1, 7: 1, 8: 5, 9: 8, 10: 23, 11: 7, 12: 2, 13: 9, 14: 16, 15: 12, 16: 33, 17: 1, 19: 1, 20: 3, 24: 1, 25: 1, 28: 2}
Throughput 66090 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 18774 | 0.428 | 0.735 | 0.017 | 0.034 | 0.009 |
| flow, no local-infra | 16579 | 0.420 | 0.720 | 0.018 | 0.035 | 0.010 |
| capture | 32 | 0.406 | 0.269 | 1.000 | 0.424 | 0.760 |

Flow ROC-AUC (max window logit) 0.554, PR-AUC 0.635; alerts per benign hour 12.5 over 5.46 h.
Time to detect (TP flows): median 0.486 s / 16 packets, p90 37.038 s / 45 packets. Decided on prefix: {5: 1, 8: 8, 9: 2, 10: 28, 11: 2, 12: 18, 13: 8, 14: 12, 15: 12, 16: 85, 17: 3, 18: 2, 19: 4, 20: 1, 21: 1, 23: 1, 28: 1}
Throughput 66758 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
