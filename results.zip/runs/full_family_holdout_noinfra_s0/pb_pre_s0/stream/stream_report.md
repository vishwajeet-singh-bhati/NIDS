# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_noinfra_s0/pb_pre_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 1.049

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 60995 | 0.444 | 0.914 | 0.071 | 0.132 | 0.010 |
| flow, no local-infra | 53813 | 0.434 | 0.926 | 0.077 | 0.142 | 0.010 |
| capture | 108 | 0.398 | 0.253 | 1.000 | 0.404 | 0.756 |

Flow ROC-AUC (max window logit) 0.654, PR-AUC 0.739; alerts per benign hour 13.3 over 18.25 h.
Time to detect (TP flows): median 1.428 s / 12 packets, p90 58.413 s / 36 packets. Decided on prefix: {4: 1, 5: 1, 6: 3, 7: 40, 8: 274, 9: 43, 10: 519, 11: 115, 12: 446, 13: 107, 14: 49, 15: 16, 16: 554, 17: 38, 18: 45, 19: 63, 20: 37, 21: 29, 22: 8, 23: 8, 24: 6, 25: 11, 26: 7, 28: 5, 29: 3, 30: 5, 31: 5, 32: 148}
Throughput 61719 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 50082 | 0.513 | 0.898 | 0.101 | 0.181 | 0.013 |
| flow, no local-infra | 43843 | 0.508 | 0.909 | 0.110 | 0.196 | 0.013 |
| capture | 106 | 0.368 | 0.247 | 1.000 | 0.396 | 0.798 |

Flow ROC-AUC (max window logit) 0.644, PR-AUC 0.694; alerts per benign hour 17.2 over 17.90 h.
Time to detect (TP flows): median 0.515 s / 12 packets, p90 36.061 s / 33 packets. Decided on prefix: {4: 1, 7: 57, 8: 107, 9: 22, 10: 762, 11: 477, 12: 214, 13: 34, 14: 15, 15: 9, 16: 505, 17: 28, 18: 29, 19: 86, 20: 46, 21: 39, 22: 11, 23: 19, 24: 7, 25: 9, 26: 7, 27: 14, 28: 35, 29: 3, 30: 13, 31: 6, 32: 138}
Throughput 58336 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
