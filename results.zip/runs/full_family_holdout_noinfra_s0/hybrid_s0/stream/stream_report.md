# Stream replay report - hybrid_resnet

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_noinfra_s0/hybrid_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 1.606

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 60995 | 0.594 | 0.979 | 0.324 | 0.487 | 0.010 |
| flow, no local-infra | 53813 | 0.605 | 0.979 | 0.358 | 0.525 | 0.012 |
| capture | 108 | 0.676 | 0.386 | 1.000 | 0.557 | 0.407 |

Flow ROC-AUC (max window logit) 0.782, PR-AUC 0.853; alerts per benign hour 13.5 over 18.25 h.
Time to detect (TP flows): median 0.408 s / 13 packets, p90 7.349 s / 46 packets. Decided on prefix: {4: 3, 6: 1, 7: 152, 8: 9951, 9: 18, 10: 147, 11: 81, 12: 119, 13: 46, 14: 62, 15: 53, 16: 928, 17: 5, 18: 8, 19: 8, 20: 15, 21: 12, 22: 3, 23: 3, 24: 2, 25: 5, 26: 1, 27: 4, 28: 2, 29: 3, 30: 4, 31: 6, 32: 98}
Throughput 17278 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 50082 | 0.625 | 0.984 | 0.303 | 0.463 | 0.006 |
| flow, no local-infra | 43843 | 0.636 | 0.984 | 0.339 | 0.504 | 0.007 |
| capture | 106 | 0.679 | 0.393 | 1.000 | 0.564 | 0.405 |

Flow ROC-AUC (max window logit) 0.779, PR-AUC 0.826; alerts per benign hour 7.5 over 17.90 h.
Time to detect (TP flows): median 0.231 s / 15 packets, p90 5.471 s / 45 packets. Decided on prefix: {4: 3, 7: 93, 8: 6682, 9: 16, 10: 100, 11: 32, 12: 78, 13: 31, 14: 63, 15: 37, 16: 847, 17: 15, 18: 6, 19: 12, 20: 4, 21: 11, 22: 3, 23: 3, 24: 7, 25: 2, 26: 3, 27: 3, 28: 5, 29: 1, 30: 1, 32: 53}
Throughput 16313 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
