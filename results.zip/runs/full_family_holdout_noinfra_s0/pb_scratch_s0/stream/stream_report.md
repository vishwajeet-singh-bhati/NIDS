# Stream replay report - packet_bert

Run: `/root/vishwajeet/android-nids/runs/full_family_holdout_noinfra_s0/pb_scratch_s0`

Threshold (val-selected, fpr, target FPR 0.01): logit 0.756

> weak capture-level labels; see src/stream/replay_eval.py docstring

## val

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 60995 | 0.431 | 0.884 | 0.049 | 0.093 | 0.009 |
| flow, no local-infra | 53813 | 0.418 | 0.886 | 0.051 | 0.097 | 0.010 |
| capture | 108 | 0.435 | 0.265 | 1.000 | 0.419 | 0.709 |

Flow ROC-AUC (max window logit) 0.633, PR-AUC 0.723; alerts per benign hour 12.8 over 18.25 h.
Time to detect (TP flows): median 1.242 s / 12 packets, p90 44.185 s / 33 packets. Decided on prefix: {4: 5, 5: 16, 6: 10, 7: 49, 8: 110, 9: 17, 10: 389, 11: 76, 12: 291, 13: 77, 14: 26, 15: 10, 16: 375, 17: 38, 18: 57, 19: 49, 20: 30, 21: 31, 22: 11, 23: 6, 24: 10, 25: 9, 26: 5, 27: 1, 28: 1, 29: 2, 30: 7, 31: 2, 32: 68}
Throughput 58721 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).

## test

| level | n | accuracy | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|
| flow | 50082 | 0.508 | 0.912 | 0.088 | 0.161 | 0.010 |
| flow, no local-infra | 43843 | 0.501 | 0.916 | 0.096 | 0.173 | 0.011 |
| capture | 106 | 0.377 | 0.250 | 1.000 | 0.400 | 0.786 |

Flow ROC-AUC (max window logit) 0.612, PR-AUC 0.667; alerts per benign hour 12.8 over 17.90 h.
Time to detect (TP flows): median 0.338 s / 11 packets, p90 28.839 s / 25 packets. Decided on prefix: {4: 8, 5: 1, 6: 9, 7: 61, 8: 79, 9: 9, 10: 740, 11: 524, 12: 159, 13: 34, 14: 13, 15: 8, 16: 352, 17: 46, 18: 28, 19: 64, 20: 40, 21: 49, 22: 16, 23: 7, 24: 14, 25: 9, 26: 7, 27: 3, 28: 13, 29: 2, 30: 5, 31: 1, 32: 64}
Throughput 55084 packets/s (includes pure-Python packet parsing + flow tracking + model, single process).
